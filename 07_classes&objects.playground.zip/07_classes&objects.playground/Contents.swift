import UIKit

//example of class and objects


//code between lines 6-10 is the class
class Can {
    let containerType = "Can"
    var stuffInside : String
   

    init(fruit : String) {
        stuffInside = fruit
        
    }
    
    func description(){
        print("\(stuffInside) are packed inside this \(containerType)")
    }
    
    func description2(numberOfFruit : Int){
        print("\(numberOfFruit)\(stuffInside) is good for you")
    }
    func description3(){
        print("\(stuffInside) are healthy for you" )
    }
    func writeCode(){
        print("\(name) is in the \(grade) grade and is coding in \(studying) all day long!")
    }
   

}
//code line 13 is object
var cannedPeaches = Can(fruit: "banana")

//the code on line 21-23 are printing our object
print(cannedPeaches)
print(cannedPeaches.containerType)
print(cannedPeaches.stuffInside)

//and the code on line 26 is calling the action/method/function within the object
cannedPeaches.description()
cannedPeaches.description2(numberOfFruit: 3)
cannedPeaches.description3()




//class Scholar {
//    let studying = "Swift"
//    var name = "Micah"
//    var grade = 11
//
//    init(personName : String, personGrade: Int) {
//        name = personName
//        grade = personGrade
//    }
//    }
//
//
//var nycScholar = Scholar(personName: "Micah", personGrade: 11)
//print(nycScholar)




