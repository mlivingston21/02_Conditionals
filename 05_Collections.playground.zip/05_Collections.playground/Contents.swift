import UIKit
//
////this is a playground for collections
//
////Initialize an Array
//
////this is the syntax for creating an empty array
//var ArrayofStrings = [String]()
//var ArrayofIntegers = [Int]()
//
////An array that stores the numbers 0,1,2,3,4
//var numbers = [0,1,2,3,4]
//
//
////this array stores 4 elements which are strings
//var friendsOfKarlie = ["Michelle Obama", "Serena Williams", "T Swift", "Jimmy Fallon"]
//print(friendsOfKarlie) // prints entire array
//print(friendsOfKarlie[1])//prints serena williams
//
////index is like the location in an array
////print jimmy fallon
//print(friendsOfKarlie[3])
//friendsOfKarlie[2] = "josh Kushner"
//print(friendsOfKarlie[2])
//print(friendsOfKarlie)
////adding information in an array
//friendsOfKarlie.append("Taylor Swift")//should be stored at index 4
//print(friendsOfKarlie)
////append automatically adds to end of an array
////challenge: how do i add in a specific location in an array
////removing information in an array
//friendsOfKarlie.remove(at: 3) //removes jimmy fallon
//print(friendsOfKarlie)
//

//
//var friendsOfMicah = ["Karen", "Taylor", "Rihanna"]
//print(friendsOfMicah)
//print(friendsOfMicah[2])
//friendsOfMicah[1] = "Hasfia"
//print(friendsOfMicah)
//friendsOfMicah.remove(at: 0)
//print(friendsOfMicah)

////Initialize an empty Dictionary
//var scholarFavColor : [String:String] = [:]
//
//scholarFavColor = [
//    "Kaitlyn":"Blue",
//    "Micah":"Blue",
//    "Audrey":"Purple",
//    "Cheyenne":"Yellow",
//]
//
//print(scholarFavColor)// wont print in order
////print audreys fav color
//print(scholarFavColor["Audrey"]) //prints optional purple
//print(scholarFavColor["Brooke"]) //print nil/ no data found
//print(scholarFavColor["Audrey"]!) //! tells swift there is data there

var familyMembers : [String:String] = [:]

familyMembers = [
    "Mom":"Dawn",
    "Dad":"Troy",
    "Sister":"Bree",
    "Sister":"Jade",
    "Dog": "Maxx",
    "Granpa":"Poppy",
    "BestFriend":"Melissa",
    "Cousin":"Gigi",
    "Uncle":"Walter",
    "Aunt":"Betty",
  ]
print(familyMembers)
 print(

