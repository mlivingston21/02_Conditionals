import UIKit

//var sponsors = ["adidas", "Estee Lauder", "Carolina Herrera Good Girl", "Apple", "WeWork"]
//
////write a for in loop for an array
//for sponsor in sponsors{ //if we see for-in this is a loop in swift
//
////sponsor is like a counter
////5 elements in sponsor means execute the code 5 times
//print("Shout out to \(sponsor) for helping make KWK happen!")
//}

var capitals = ["France": "Paris",
                "Cuba":"Havana",
                "Japan":"Tokoyo"]
//keys are the countries
//values are the cities
//elements are the key/value pair such as France:Paris



//a loop that iterates each element of the dictionary
for pair in capitals{
    print(pair)
}
//a loop that specifically prints each country and capital separately

for(country, cities) in capitals{
    //"the capital of france is paris...etc
    print("the capital of \(country) is \(cities)!")
}

for pair in capitals {
    print("the cpaital of \(pair.key) is \(pair.value)!")
}

//loop that didnt need a counter
for _ in 1...4{
    print("Hello World!")
}
for _ in 50..<54{
   print("Hello World!")
}

//var names = ["lucy", "Bailey", "Alice", "Emma", "sally"]
//
//for x in names{
//    print("Hello, \(x)")
//
//}


